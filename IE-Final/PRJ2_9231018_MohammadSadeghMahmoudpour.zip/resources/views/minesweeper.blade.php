<!DOCTYPE html>
<html>

<head>
    <script src="vendor/jquery-3.1.1.min.js"></script>
    <link rel="stylesheet" href="css/minesweeper.css">
</head>

<body>


<!--<script src="https://rawgit.com/AUT-CEIT/ie/master/2016/fall/HW-3/js/lib.js"></script>-->
<script src="js/lib.js"></script>
<script src="js/minesweeper.js"></script>
</body>
</html>