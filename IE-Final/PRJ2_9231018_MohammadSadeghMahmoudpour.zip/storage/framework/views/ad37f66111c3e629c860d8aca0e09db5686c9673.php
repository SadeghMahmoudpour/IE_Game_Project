<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo $__env->yieldContent('meta-title', 'Larademo'); ?></title>

    <link rel="stylesheet" href="//netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/style.css">
</head>

<body>
<div class="navbar navbar-inverse navbar-fixed-top" role="navigation">
    <div class="container">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="/">Larademo</a>
        </div>
        <div class="collapse navbar-collapse">
            <ul class="nav navbar-nav">
                <li><a href="/">Home</a></li>

                <?php if(Auth::guest()): ?>
                <li><a href="/register">Register</a></li>
                <li><a href="/login">Login</a></li>
                <?php else: ?>
                <li><?php echo e(link_to_profile()); ?></li>
                <li><a href="/logout">Logout</a></li>
                <?php endif; ?>
            </ul>
        </div><!--/.nav-collapse -->
    </div>
</div>

<div class="container">
    <div class="row">
        <div class="col-md-7">
            <h1>Edit Profile</h1>

            <?php echo e(Form::model($user->profile, ['method' => 'PATCH', 'route' => ['profile.update', $user->username]])); ?>

            <!-- Location Field -->
            <div class="form-group">
                <?php echo e(Form::label('location', 'Location:')); ?>

                <?php echo e(Form::text('location', null, ['class' => 'form-control'])); ?>

                <?php echo e(errors_for('location', $errors)); ?>

            </div>

            <!-- Bio Field -->
            <div class="form-group">
                <?php echo e(Form::label('bio', 'Bio:')); ?>

                <?php echo e(Form::textarea('bio', null, ['class' => 'form-control'])); ?>

                <?php echo e(errors_for('bio', $errors)); ?>

            </div>

            <!-- Twitter_username Field -->
            <div class="form-group">
                <?php echo e(Form::label('twitter_username', 'Twitter_username:')); ?>

                <?php echo e(Form::text('twitter_username', null, ['class' => 'form-control'])); ?>

                <?php echo e(errors_for('twitter_username', $errors)); ?>


            </div>

            <!-- Github_username Field -->
            <div class="form-group">
                <?php echo e(Form::label('github_username', 'Github_username:')); ?>

                <?php echo e(Form::text('github_username', null, ['class' => 'form-control'])); ?>

                <?php echo e(errors_for('github_username', $errors)); ?>

            </div>

            <!-- Update Profile Field -->
            <div class="form-group">
                <?php echo e(Form::submit('Update Profile', ['class' => 'btn btn-primary'])); ?>

            </div>
            <?php echo e(Form::close()); ?>

        </div>
    </div>
</div>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
</body>
</html>