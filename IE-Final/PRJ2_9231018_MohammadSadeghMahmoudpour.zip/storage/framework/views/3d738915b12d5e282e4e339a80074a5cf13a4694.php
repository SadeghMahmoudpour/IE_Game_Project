<?php $__env->startSection('content'); ?>
<?php if($user): ?>
    <h1><?php echo e($user->name); ?>

    </h1>
<?php else: ?>
    <p>No profile yet.</p>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts/layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>