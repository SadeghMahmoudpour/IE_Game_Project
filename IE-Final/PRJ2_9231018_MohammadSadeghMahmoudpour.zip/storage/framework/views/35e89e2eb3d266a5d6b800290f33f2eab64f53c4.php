<!DOCTYPE html>
<html lang="fa">
<head>
    <meta charset="utf-8">

    <title>admin</title>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>

    <link rel="stylesheet" href="../css/hw2-global.css" type="text/css">
    <link rel="stylesheet" href="../css/login.css" type="text/css">
</head>
<body>
<header class="site_header">
    <div class="header_wrap">
        <!--        <span class="header_image"><i class="material-icons md-light md-48">person</i></span>-->
        <div class="header_widget">
            <ul class="menu">
                <li class="menu_item">
                    <a href="/">امیرکبیر <span style="color: #337ab7;">استودیو</span> <i class="fa fa-gamepad" aria-hidden="true"></i></a>
                </li>
            </ul>
        </div>
    </div>
</header>
<div class="site_inner">
    <div class="card_outer">
        <div class="card_miidle">
            <div class="card_inner">
                <div class="card_header canter_text">ورود ادمین</div>
                <div class="card_body">
                    <?php echo Form::model(['method' => 'POST', 'route' => ['admin.edit']]); ?>

                    <div class="form-group card_form">
                        <?php echo Form::password('password', ['class'=>'form-control', 'id' => 'password-input', 'placeholder' => 'رمز عبور', 'required' => 'required']); ?>

                        <?php echo e($errors->first('password', '<span
                            class=error>Unvalid Password</span>')); ?>

                        <i class="material-icons card_icon">lock</i>
                    </div>
                    <div class="form-group">
                        <?php echo e(Form::submit('ورود', ['class' => 'btn btn-primary'])); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
</body>
</html>